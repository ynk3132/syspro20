#include<stdio.h>

typedef unsigned char *pointer;

void show_bytes(pointer start, size_t len){
	size_t j;
	for(j=0;j<len;j++)
		printf("%p\t0x%.2x\n",start+j,start[j]);
	printf("\n");
	if(start[j]!=0)
		printf("이 컴퓨터는 Litte-endian입니다.");
	else printf("이 컴퓨터는 Big-endian입니다.");
}
int main(){
	long i;
	int a=15213;
	printf("이 컴퓨터는 %ldbit입니다.\n",sizeof(i)*8);
	printf("int a=15213:\n");
	show_bytes((pointer)&a,sizeof(int));
	return 0;
}
